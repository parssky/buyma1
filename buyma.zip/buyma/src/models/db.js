const mysql = require('mysql')

var connection = mysql.createConnection({
    host     : process.env.HOST,
    user     : process.env.USER,
    password : '',
    database : process.env.DATABASE_NAME
  });

  connection.connect(function(err) {
    if (err) {
      console.error('error connecting: ' + err.stack);
      return;
    }
   
    console.log('DataBase connected as id ' + connection.threadId);
  });

  module.exports = connection
  